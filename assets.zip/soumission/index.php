<!DOCTYPE html>
<html>
<?php 
    $metaDesc ="Notre équipe d’experts assurera un produit de la meilleure qualité pour vous assurer un produit durable et résistant aux tremblements de terre pour l’agrandissement de votre maison.";
    $englishUrl = "/en/soumission";
    include_once(__DIR__."/../head.php");
?>
<body >
  <?php include(__DIR__."/../header.php")?>

  <div class="container">  
      <div data-paperform-id="lesentrerpisesasraca"></div>
    </div>
  </div>
  <?php include(__DIR__."/../footing.php")?>
</body>
</html>